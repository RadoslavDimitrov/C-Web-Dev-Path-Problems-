﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedTrip.Models.Trips
{
    public class UsersTripInputModel
    {
        public string Username { get; set; }
        public string Email { get; set; }
    }
}
