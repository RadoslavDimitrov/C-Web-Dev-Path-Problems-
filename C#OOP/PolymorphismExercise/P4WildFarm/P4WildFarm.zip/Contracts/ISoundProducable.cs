﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P4WildFarm.Contracts
{
    public interface ISoundProducable
    {
        void ProduceSound();
    }
}
