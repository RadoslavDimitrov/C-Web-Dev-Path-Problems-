﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P4WildFarm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
