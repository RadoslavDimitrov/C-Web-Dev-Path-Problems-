﻿using P3Raiding.Core;
using System;

namespace P3Raiding
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
