﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Enums
{
    public enum PlayerTypes
    {
        Terrorist = 1,
        CounterTerrorist = 2
    }
}
