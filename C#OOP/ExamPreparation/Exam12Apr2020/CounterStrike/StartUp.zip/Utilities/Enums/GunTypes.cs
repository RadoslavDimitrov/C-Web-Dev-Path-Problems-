﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Enums
{
    public enum GunTypes
    {
        Pistol = 1,
        Rifle = 2
    }
}
