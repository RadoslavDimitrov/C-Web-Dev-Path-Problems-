﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Utilities.Enums
{
    public enum RobotType
    {

        PetRobot = 1,
        HouseholdRobot = 2,
        WalkerRobot = 3
    }
}
