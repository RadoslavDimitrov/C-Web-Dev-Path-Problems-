﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P5BirthdayCelebrations
{
    public interface IBirthable
    {
        string Name { get; }
        string BirthDay { get; }
    }
}
