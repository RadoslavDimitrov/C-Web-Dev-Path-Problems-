﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P3Telephony
{
    public interface IWebSearchable
    {
        string SearchWeb();
    }
}
