﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P7MilitaryElite
{
    public interface ILieutenantGeneral
    {
        void AddPrivate(Private currPrivate);
    }
}
