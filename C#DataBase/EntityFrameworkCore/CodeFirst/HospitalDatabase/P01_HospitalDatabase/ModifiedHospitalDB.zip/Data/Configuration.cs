﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    internal static class Configuration
    {
        internal const string ConnectionString = @"Server = .\SQLEXPRESS;Database = HospitalDB;Integrated Security = true;";
    }
}
