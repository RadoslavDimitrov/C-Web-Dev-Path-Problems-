﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public static class ConnectionConfiguration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=SalesDatabase;Integrated Security = true;";
    }
}
