﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        private static string ResultsDirectoryPath = "../../../Datasets/Results";
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            //Problem 4
            string input = File.ReadAllText("../../../Datasets/categories-products.json");
            string result = ImportCategoryProducts(context, input);

            //Problem 3
            //string input = File.ReadAllText("../../../Datasets/categories.json");
            //string result = ImportCategories(context, input);

            //Problem 2
            //string input = File.ReadAllText("../../../Datasets/products.json");

            //string result = ImportProducts(context, input);


            //Problem 1
            //string input = File.ReadAllText("../../../Datasets/users.json");

            //string result = ImportUsers(context, input);

            Console.WriteLine(result);
        }

        //Problem 4
        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            List<CategoryProduct> categoryProducts = JsonConvert.DeserializeObject<List<CategoryProduct>>(inputJson);

            context.CategoryProducts.AddRange(categoryProducts);

            int count = categoryProducts.Count;

            context.SaveChanges();

            return $"Successfully imported {count}";
        }

        //Problem 3
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            List<Category> categories = JsonConvert.DeserializeObject<List<Category>>(inputJson)
                .Where(x => x.Name != null)
                .ToList();

            context.Categories.AddRange(categories);

            int count = categories.Count;

            context.SaveChanges();

            return $"Successfully imported {count}";
        }

        //Problem 2
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            List<Product> products = JsonConvert.DeserializeObject<List<Product>>(inputJson);

            context.Products.AddRange(products);

            int count = products.Count;

            context.SaveChanges();

            return $"Successfully imported {count}";
        }

        //problem 1
        public static string ImportUsers(ProductShopContext context, string inputjson)
        {
            List<User> users = JsonConvert.DeserializeObject<List<User>>(inputjson);

            context.Users.AddRange(users);

            int count = users.Count;

            context.SaveChanges();

            return $"Successfully imported {count}";
        }

        private static void ResetDatabase(ProductShopContext context)
        {
            context.Database.EnsureDeleted();
            Console.WriteLine("Database was successfully deleted!");

            context.Database.EnsureCreated();
            Console.WriteLine("Database was successfully created!");
        }
    }
}