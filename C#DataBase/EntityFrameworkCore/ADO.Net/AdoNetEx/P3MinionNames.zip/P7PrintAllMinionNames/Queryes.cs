﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P7PrintAllMinionNames
{
    public static class Queryes
    {
        public static string GetAllMinionNames = "SElECT [Name] FROM Minions";
    }
}
