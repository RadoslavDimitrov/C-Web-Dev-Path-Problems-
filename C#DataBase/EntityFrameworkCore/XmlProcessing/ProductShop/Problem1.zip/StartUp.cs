﻿using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XmlHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var usersImport = File.ReadAllText("../../../Datasets/users.xml");
            var result = ImportUsers(context, usersImport);
            Console.WriteLine(result);
        }

        //Problem 1

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            var userAttribute = "Users";

            var users = XmlConverter.Deserializer<InsertUsersDto>(inputXml, userAttribute);

            List<User> usersAsObj = users.Select(x => new User
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                Age = x.Age
            })
                .ToList();

            context.Users.AddRange(usersAsObj);
            context.SaveChanges();

            return $"Successfully imported {usersAsObj.Count}";
        }
    }
}