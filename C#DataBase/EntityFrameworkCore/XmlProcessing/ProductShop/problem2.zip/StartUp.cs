﻿using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XmlHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            //Problem 1
            var usersImport = File.ReadAllText("../../../Datasets/users.xml");

            var xmlInput = File.ReadAllText("../../../Datasets/products.xml");

            ImportUsers(context, usersImport);
            

            //Problem 2

            var resultProduct = ImportProducts(context, xmlInput);
            Console.WriteLine(resultProduct);
        }

        //Problem 2

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            var productRootAttribute = "Products";

            var productsDto = XmlConverter.Deserializer<InsertProductsDto>(inputXml, productRootAttribute);

            var products = productsDto.Select(x => new Product
            {
                Name = x.Name,
                Price = x.Price,
                BuyerId = x.BuyerId,
                SellerId = x.SellerId
            })
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Length}";
        }

        //Problem 1

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            var userAttribute = "Users";

            var users = XmlConverter.Deserializer<InsertUsersDto>(inputXml, userAttribute);

            List<User> usersAsObj = users.Select(x => new User
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                Age = x.Age
            })
                .ToList();

            context.Users.AddRange(usersAsObj);
            context.SaveChanges();

            return $"Successfully imported {usersAsObj.Count}";
        }
    }
}