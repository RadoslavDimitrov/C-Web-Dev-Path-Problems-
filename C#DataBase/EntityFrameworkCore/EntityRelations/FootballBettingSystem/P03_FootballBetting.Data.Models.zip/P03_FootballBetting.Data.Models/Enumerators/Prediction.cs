﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models.Enumerators
{
    public enum Prediction
    {
        Win = 1,
        Draw = 0,
        Lose = -1
    }
}
